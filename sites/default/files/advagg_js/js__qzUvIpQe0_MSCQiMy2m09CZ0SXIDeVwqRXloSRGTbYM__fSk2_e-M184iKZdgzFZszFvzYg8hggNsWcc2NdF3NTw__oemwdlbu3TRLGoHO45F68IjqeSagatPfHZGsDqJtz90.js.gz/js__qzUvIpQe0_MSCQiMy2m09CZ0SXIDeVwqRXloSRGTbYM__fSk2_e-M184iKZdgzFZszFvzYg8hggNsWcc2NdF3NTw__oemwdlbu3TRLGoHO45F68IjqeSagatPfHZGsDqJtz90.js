Drupal.locale = { 'strings': {"":{"An AJAX HTTP error occurred.":"C\u00f3 l\u1ed7i AJAX HTTP.","HTTP Result Code: !status":"K\u1ebft qu\u1ea3 m\u00e3 HTTP: !status","An AJAX HTTP request terminated abnormally.":"Y\u00eau c\u1ea7u AJAX HTTP k\u1ebft th\u00fac b\u1ea5t th\u01b0\u1eddng.","Debugging information follows.":"R\u00e0 l\u1ed7i theo th\u00f4ng tin sau.","Path: !uri":"\u0110\u01b0\u1eddng d\u1eabn: !uri","StatusText: !statusText":"StatusText: !statusText","ResponseText: !responseText":"ResponseTextt: !responseText","ReadyState: !readyState":"ReadyState: !readyState","All":"T\u1ea5t c\u1ea3","Hide":"\u1ea8n","Show":"Hi\u1ec7n","Edit":"S\u1eeda","Add":"Th\u00eam","Configure":"C\u1ea5u h\u00ecnh","This field is required.":"Tr\u01b0\u1eddng d\u1eef li\u1ec7u n\u00e0y l\u00e0 b\u1eaft bu\u1ed9c.","Select all rows in this table":"Ch\u1ecdn t\u1ea5t c\u1ea3 c\u00e1c d\u00f2ng trong b\u1ea3ng n\u00e0y","Deselect all rows in this table":"B\u1ecf ch\u1ecdn t\u1ea5t c\u1ea3 c\u00e1c d\u00f2ng trong b\u1ea3ng n\u00e0y","Not published":"Ch\u01b0a c\u00f4ng b\u1ed1","Please wait...":"Vui l\u00f2ng \u0111\u1ee3i...","By @name on @date":"B\u1edfi @name v\u00e0o l\u00fac @date","By @name":"@name vi\u1ebft","Not in menu":"Kh\u00f4ng c\u00f3 trong tr\u00ecnh \u0111\u01a1n","Alias: @alias":"\u0110\u01b0\u1eddng d\u1eabn \u1ea3o: @alias","No alias":"Ch\u01b0a c\u00f3 \u0111\u01b0\u1eddng d\u1eabn \u1ea3o","New revision":"Phi\u00ean b\u1ea3n m\u1edbi","Drag to re-order":"K\u00e9o \u0111\u1ec3 s\u1eafp x\u1ebfp l\u1ea1i","Changes made in this table will not be saved until the form is submitted.":"C\u00e1c thay \u0111\u1ed5i \u0111\u01b0\u1ee3c th\u1ef1c hi\u1ec7n trong b\u1ea3ng n\u00e0y s\u1ebd kh\u00f4ng \u0111\u01b0\u1ee3c l\u01b0u cho \u0111\u1ebfn khi bi\u1ec3u m\u1eabu \u0111\u01b0\u1ee3c \u0111\u1ec7 tr\u00ecnh.","The changes to these blocks will not be saved until the \u003Cem\u003ESave blocks\u003C\/em\u003E button is clicked.":"C\u00e1c thay \u0111\u1ed5i \u0111\u1ed1i v\u1edbi c\u00e1c kh\u1ed1i n\u1ed9i dung n\u00e0y s\u1ebd ch\u01b0a \u0111\u01b0\u1ee3c l\u01b0u cho \u0111\u1ebfn khi n\u00fat \u003Cem\u003EL\u01b0u c\u00e1c kh\u1ed1i n\u1ed9i dung\u003C\/em\u003E \u0111\u01b0\u1ee3c nh\u1ea5p.","This permission is inherited from the authenticated user role.":"Quy\u1ec1n n\u00e0y \u0111\u01b0\u1ee3c k\u1ebf th\u1eeba t\u1eeb vai tr\u00f2 ng\u01b0\u1eddi d\u00f9ng \u0111\u00e3 x\u00e1c th\u1ef1c.","No revision":"Kh\u00f4ng c\u00f3 phi\u00ean b\u1ea3n n\u00e0o","@number comments per page":"@number l\u1eddi b\u00ecnh m\u1ed7i trang","Requires a title":"Ph\u1ea7n ti\u00eau \u0111\u1ec1 l\u00e0 b\u1eaft bu\u1ed9c","Not restricted":"Kh\u00f4ng h\u1ea1n ch\u1ebf","(active tab)":"(tab ho\u1ea1t \u0111\u1ed9ng)","Not customizable":"Ng\u01b0\u1eddi d\u00f9ng kh\u00f4ng \u0111\u01b0\u1ee3c ph\u00e9p t\u00f9y ch\u1ec9nh","Restricted to certain pages":"H\u1ea1n ch\u1ebf \u0111\u1ed1i v\u1edbi m\u1ed9t s\u1ed1 trang","The block cannot be placed in this region.":"Kh\u00f4ng th\u1ec3 \u0111\u01b0a kh\u1ed1i n\u00e0y v\u00e0o v\u00f9ng n\u00e0y.","Hide summary":"\u1ea8n t\u00f3m t\u1eaft","Edit summary":"S\u1eeda t\u00f3m t\u1eaft","Don\u0027t display post information":"Hi\u1ec3n th\u1ecb tho\u1ea1i th\u00f4ng tin ch\u1eef","The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.":"T\u00ean t\u1ec7p %filename kh\u00f4ng \u0111\u01b0\u1ee3c ph\u00e9p t\u1ea3i l\u00ean. Ch\u1ec9 c\u00f3 c\u00e1c t\u1ec7p v\u1edbi ph\u1ea7n m\u1edf r\u1ed9ng sau l\u00e0 \u0111\u01b0\u1ee3c ph\u00e9p: %extensions.","Re-order rows by numerical weight instead of dragging.":"S\u1eafp x\u1ebfp l\u1ea1i danh m\u1ee5c theo \u0111\u1ed9 n\u1eb7ng thay v\u00ec k\u00e9o ch\u00fang.","Show row weights":"Hi\u1ec7n tr\u1ecdng s\u1ed1 h\u00e0ng","Hide row weights":"\u1ea8n tr\u1ecdng s\u1ed1 h\u00e0ng","Autocomplete popup":"B\u1eadt l\u00ean t\u1ef1 ho\u00e0n t\u1ea5t","Searching for matches...":"T\u00ecm kh\u1edbp..."}} };;/**/
(function($) {
  Drupal.behaviors.custom_search = {
    attach: function(context) {

      if (!Drupal.settings.custom_search.solr) {
        // Check if the search box is not empty on submit
        $('form.search-form', context).submit(function(){
          var $this = $(this);
          var box = $this.find('input.custom-search-box');
          if (box.val() != undefined && box.val() == '') {
            $this.find('input.custom-search-box').addClass('error');
            return false;
          }
          // If basic search is hidden, copy or value to the keys
          if ($this.find('#edit-keys').parents('div.element-invisible').attr('class') == 'element-invisible') {
            $this.find('#edit-keys').val($this.find('#edit-or').val());
            $this.find('#edit-or').val('');
          }
          return true;
        });
      }

      // Search from target
      $('form.search-form').attr('target', Drupal.settings.custom_search.form_target);

      // Displays Popup.
      $('form.search-form input.custom-search-box', context).bind('click focus', function(e){
        var $parentForm = $(this).parents('form');
        // check if there's something in the popup and displays it
        var popup = $parentForm.find('fieldset.custom_search-popup');
        if (popup.find('input,select').length && !popup.hasClass('opened')) {
          popup.fadeIn().addClass('opened');
        }
        e.stopPropagation();
      });
      $(document).bind('click focus', function(){
        $('fieldset.custom_search-popup').hide().removeClass('opened');
      });

      // Handle checkboxes
      $('.custom-search-selector input:checkbox', context).each(function(){
        var el = $(this);
        if (el.val() == 'c-all') {
          el.change(function(){
            $(this).parents('.custom-search-selector').find('input:checkbox[value!=c-all]').attr('checked', false);
          });
        }
        else {
          if (el.val().substr(0,2) == 'c-') {
            el.change(function(){
              $('.custom-search-selector input:checkbox').each(function(){
                if ($(this).val().substr(0,2) == 'o-') {
                  $(this).attr('checked', false);
                }
              });
              $(this).parents('.custom-search-selector').find('input:checkbox[value=c-all]').attr('checked', false);
            });
          } else {
            el.change(function(){
              $(this).parents('.custom-search-selector').find('input:checkbox[value!=' + el.val() + ']').attr('checked', false);
            });
          }
        }
      });

      // Handle popup.
      var popup = $('fieldset.custom_search-popup:not(.custom_search-processed)', context).addClass("custom_search-processed");
      popup.click(function(e){
        e.stopPropagation();
      })
      popup.append('<a class="custom_search-popup-close" href="#">' + Drupal.t('Close') + '</a>');
      $('a.custom_search-popup-close').click(function(e){
        $('fieldset.custom_search-popup.opened').hide().removeClass('opened');
        e.preventDefault();
      });

    }
  }
})(jQuery);
;/**/
